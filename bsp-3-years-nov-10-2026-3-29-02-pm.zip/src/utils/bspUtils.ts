import { IndicatorRow, ActivityBudgetRow, BudgetYearSource } from '../data/bspData';

/**
 * Parse a string number with commas, percentage, or text into a clean numeric value.
 */
export function parseNumber(val: string | number | undefined | null): number {
  if (val === undefined || val === null) return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  const cleaned = val.replace(/,/g, '').replace(/%/g, '').trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
}

/**
 * Format a number as Cambodian Riel or standard comma-separated integer.
 */
export function formatRiel(val: number | string | undefined | null): string {
  if (val === undefined || val === null || val === '') return '';
  const num = typeof val === 'number' ? val : parseNumber(val);
  if (num === 0) return '0';
  return num.toLocaleString('en-US');
}

/**
 * Calculate totals for Table 1 (Performance Indicators).
 * Dynamically computes subtotals for each Standard (1-5) and Grand Total.
 */
export function computeTable1Summaries(rows: IndicatorRow[]) {
  const standardTotals: Record<number, { budgetN1: number; targetN1Budget: number }> = {
    1: { budgetN1: 0, targetN1Budget: 0 },
    2: { budgetN1: 0, targetN1Budget: 0 },
    3: { budgetN1: 0, targetN1Budget: 0 },
    4: { budgetN1: 0, targetN1Budget: 0 },
    5: { budgetN1: 0, targetN1Budget: 0 },
  };

  rows.forEach((row) => {
    // Only accumulate KEY_INDICATOR rows so we don't double count sub-indicators or standard headers
    if (row.category === 'KEY_INDICATOR' && row.standardId >= 1 && row.standardId <= 5) {
      const budget = parseNumber(row.budgetYearN1);
      const targetBudget = parseNumber(row.targetNPlus1);
      standardTotals[row.standardId].budgetN1 += budget;
      standardTotals[row.standardId].targetN1Budget += targetBudget;
    }
  });

  const grandTotalBudgetN1 = Object.values(standardTotals).reduce((sum, curr) => sum + curr.budgetN1, 0);
  const grandTotalTargetN1 = Object.values(standardTotals).reduce((sum, curr) => sum + curr.targetN1Budget, 0);

  return {
    standardTotals,
    grandTotalBudgetN1,
    grandTotalTargetN1,
  };
}

/**
 * Calculate totals for Table 2 (Financial Resources and Activities).
 */
export interface Table2ComputedTotal {
  state: number;
  partner: number;
  community: number;
  other: number;
  total: number;
}

export function computeTable2Summaries(rows: ActivityBudgetRow[]) {
  const emptyTotal = (): Table2ComputedTotal => ({ state: 0, partner: 0, community: 0, other: 0, total: 0 });

  const standardTotals: Record<number, {
    yearN: Table2ComputedTotal;
    yearN1: Table2ComputedTotal;
    yearN2: Table2ComputedTotal;
    yearN3: Table2ComputedTotal;
  }> = {
    1: { yearN: emptyTotal(), yearN1: emptyTotal(), yearN2: emptyTotal(), yearN3: emptyTotal() },
    2: { yearN: emptyTotal(), yearN1: emptyTotal(), yearN2: emptyTotal(), yearN3: emptyTotal() },
    3: { yearN: emptyTotal(), yearN1: emptyTotal(), yearN2: emptyTotal(), yearN3: emptyTotal() },
    4: { yearN: emptyTotal(), yearN1: emptyTotal(), yearN2: emptyTotal(), yearN3: emptyTotal() },
    5: { yearN: emptyTotal(), yearN1: emptyTotal(), yearN2: emptyTotal(), yearN3: emptyTotal() },
  };

  const grandTotal = {
    yearN: emptyTotal(),
    yearN1: emptyTotal(),
    yearN2: emptyTotal(),
    yearN3: emptyTotal(),
  };

  const accumulate = (target: Table2ComputedTotal, source: BudgetYearSource) => {
    const s = parseNumber(source.state);
    const p = parseNumber(source.partner);
    const c = parseNumber(source.community);
    const o = parseNumber(source.other);
    target.state += s;
    target.partner += p;
    target.community += c;
    target.other += o;
    target.total += s + p + c + o;
  };

  rows.forEach((row) => {
    if (row.category === 'ACTIVITY' && row.standardId >= 1 && row.standardId <= 5) {
      accumulate(standardTotals[row.standardId].yearN, row.yearN);
      accumulate(standardTotals[row.standardId].yearN1, row.yearN1);
      accumulate(standardTotals[row.standardId].yearN2, row.yearN2);
      accumulate(standardTotals[row.standardId].yearN3, row.yearN3);

      accumulate(grandTotal.yearN, row.yearN);
      accumulate(grandTotal.yearN1, row.yearN1);
      accumulate(grandTotal.yearN2, row.yearN2);
      accumulate(grandTotal.yearN3, row.yearN3);
    }
  });

  return {
    standardTotals,
    grandTotal,
  };
}

/**
 * Automatically sync Table 1 (Table 4) budget columns into Table 2 (Table 5):
 * Per MoEYS 2026-2028 cycle rule:
 * 1. Table 4 "ឆ្នាំគ្រោងថវិកា (ឆ្នាំ N+1) (រៀល)" (budgetYearN1) -> Table 5 "ច្បាប់ហិរញ្ញវត្ថុ ឆ្នាំ N (ថវិការដ្ឋ)" (yearN.state)
 * 2. Table 4 "គោលដៅ (ឯកតារៀលគត់ / %)" (targetNPlus1) -> Table 5 "គម្រោងតម្រូវការឥណទាន ឆ្នាំ N+1 (ថវិការដ្ឋ)" (yearN1.state)
 *
 * Matches each activity in Table 2 to its corresponding key indicator in Table 1
 * by Standard ID (1-5) and sequential index within that standard.
 */
export function syncTable1ToTable2(
  t1Rows: IndicatorRow[],
  t2Rows: ActivityBudgetRow[]
): ActivityBudgetRow[] {
  // Group key indicators by standardId
  const keyIndicatorsByStandard: Record<number, IndicatorRow[]> = {
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
  };

  t1Rows.forEach((row) => {
    if (row.category === 'KEY_INDICATOR' && row.standardId >= 1 && row.standardId <= 5) {
      keyIndicatorsByStandard[row.standardId].push(row);
    }
  });

  const activityIndexByStandard: Record<number, number> = {
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
  };

  return t2Rows.map((row) => {
    if (row.category !== 'ACTIVITY' || row.standardId < 1 || row.standardId > 5) {
      return row;
    }

    const stdId = row.standardId;
    const actIdx = activityIndexByStandard[stdId];
    activityIndexByStandard[stdId] += 1;

    const matchedKey = keyIndicatorsByStandard[stdId]?.[actIdx];
    if (!matchedKey) return row;

    return {
      ...row,
      yearN: {
        ...row.yearN,
        // ឆ្នាំគ្រោងថវិកា N+1 ក្នុងតារាងទី៤ គឺជា ច្បាប់ហិរញ្ញវត្ថុ ក្នុងតារាងទី៥
        state: matchedKey.budgetYearN1 ? formatRiel(matchedKey.budgetYearN1) : row.yearN.state,
      },
      yearN1: {
        ...row.yearN1,
        // N+1 ក្នុងតារាងទី៥ គឺជា ថវិកាគោលដៅ ក្នុងតារាងទី៤
        state: matchedKey.targetNPlus1 ? formatRiel(matchedKey.targetNPlus1) : row.yearN1.state,
      },
    };
  });
}

/**
 * Reverse sync: if user edits Year N or Year N+1 state budget in Table 2,
 * propagate to the matching Key Indicator in Table 1.
 */
export function syncTable2ToTable1(
  t2Rows: ActivityBudgetRow[],
  t1Rows: IndicatorRow[]
): IndicatorRow[] {
  const activitiesByStandard: Record<number, ActivityBudgetRow[]> = {
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
  };

  t2Rows.forEach((row) => {
    if (row.category === 'ACTIVITY' && row.standardId >= 1 && row.standardId <= 5) {
      activitiesByStandard[row.standardId].push(row);
    }
  });

  const keyIndicatorIndexByStandard: Record<number, number> = {
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
  };

  return t1Rows.map((row) => {
    if (row.category !== 'KEY_INDICATOR' || row.standardId < 1 || row.standardId > 5) {
      return row;
    }

    const stdId = row.standardId;
    const keyIdx = keyIndicatorIndexByStandard[stdId];
    keyIndicatorIndexByStandard[stdId] += 1;

    const matchedActivity = activitiesByStandard[stdId]?.[keyIdx];
    if (!matchedActivity) return row;

    return {
      ...row,
      // ច្បាប់ហិរញ្ញវត្ថុ (yearN.state) គឺជា ឆ្នាំគ្រោងថវិកា N+1 (budgetYearN1)
      budgetYearN1: matchedActivity.yearN.state
        ? formatRiel(matchedActivity.yearN.state)
        : row.budgetYearN1,
      // គម្រោងតម្រូវការ N+1 (yearN1.state) គឺជា ថវិកាគោលដៅ (targetNPlus1)
      targetNPlus1: matchedActivity.yearN1.state
        ? formatRiel(matchedActivity.yearN1.state)
        : row.targetNPlus1,
    };
  });
}

/**
 * Export data to CSV with UTF-8 BOM for Khmer text support in Excel.
 */
export function exportToCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const bom = '\uFEFF';
  const csvContent = [
    headers.map((h) => `"${String(h).replace(/"/g, '""')}"`).join(','),
    ...rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')),
  ].join('\r\n');

  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

