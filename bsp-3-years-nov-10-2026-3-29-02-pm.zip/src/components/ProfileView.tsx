import React from 'react';
import { SchoolProfile } from '../data/bspData';
import {
  Building,
  Calendar,
  UserCheck,
  FileText,
  Save,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface ProfileViewProps {
  schoolProfile: SchoolProfile;
  onUpdateProfile: (updated: Partial<SchoolProfile>) => void;
  onResetConclusion: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  schoolProfile,
  onUpdateProfile,
  onResetConclusion,
}) => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Title */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-6 bg-amber-500 rounded-full inline-block"></span>
          <h2 className="text-base md:text-lg font-bold text-slate-900">
            ព័ត៌មានទូទៅរបស់សាលារៀន និងសេចក្តីសន្និដ្ឋាន (School Profile & Conclusion)
          </h2>
        </div>
        <p className="text-xs text-slate-500 mt-1 pl-4.5">
          កំណត់ព័ត៌មានស្ថាប័ន ឆ្នាំសិក្សា គណៈគ្រប់គ្រង និងខ្លឹមសារសេចក្តីសន្និដ្ឋានផ្លូវការសម្រាប់ឯកសារ BSP ៣ ឆ្នាំ
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: School Identity */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-800 font-semibold text-sm">
            <Building className="w-4 h-4 text-indigo-600" />
            <span>ព័ត៌មានអត្តសញ្ញាណសាលារៀន</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-600 font-medium mb-1">
                ឈ្មោះសាលារៀន (School Name)
              </label>
              <input
                type="text"
                value={schoolProfile.schoolName}
                onChange={(e) => onUpdateProfile({ schoolName: e.target.value })}
                placeholder="ឧ. សាលាបឋមសិក្សា..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  អត្តលេខ/កូដសាលា
                </label>
                <input
                  type="text"
                  value={schoolProfile.schoolCode}
                  onChange={(e) => onUpdateProfile({ schoolCode: e.target.value })}
                  placeholder="SCH-..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-none font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  កម្រងសាលារៀន (Cluster)
                </label>
                <input
                  type="text"
                  value={schoolProfile.cluster}
                  onChange={(e) => onUpdateProfile({ cluster: e.target.value })}
                  placeholder="កម្រង..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  ស្រុក/ខណ្ឌ
                </label>
                <input
                  type="text"
                  value={schoolProfile.district}
                  onChange={(e) => onUpdateProfile({ district: e.target.value })}
                  placeholder="ស្រុក/ខណ្ឌ..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  ខេត្ត/រាជធានី
                </label>
                <input
                  type="text"
                  value={schoolProfile.province}
                  onChange={(e) => onUpdateProfile({ province: e.target.value })}
                  placeholder="ខេត្ត/រាជធានី..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Card 2: Strategic Plan Years */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-800 font-semibold text-sm">
            <Calendar className="w-4 h-4 text-sky-600" />
            <span>ការកំណត់ឆ្នាំផែនការ (N-1, N, N+1, N+2, N+3)</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  ឆ្នាំមុន (ឆ្នាំ N-1)
                </label>
                <input
                  type="number"
                  value={schoolProfile.yearNMinus1}
                  onChange={(e) => onUpdateProfile({ yearNMinus1: parseInt(e.target.value) || 2024 })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:outline-none font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  ឆ្នាំបច្ចុប្បន្ន (ឆ្នាំ N)
                </label>
                <input
                  type="number"
                  value={schoolProfile.yearN}
                  onChange={(e) => {
                    const n = parseInt(e.target.value) || 2025;
                    onUpdateProfile({
                      yearN: n,
                      yearNMinus1: n - 1,
                      yearN1: n + 1,
                      yearN2: n + 2,
                      yearN3: n + 3,
                    });
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:outline-none font-mono font-bold text-sky-900 bg-sky-50/50"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1">
              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                  ឆ្នាំគ្រោង (N+1)
                </label>
                <input
                  type="number"
                  value={schoolProfile.yearN1}
                  onChange={(e) => onUpdateProfile({ yearN1: parseInt(e.target.value) || 2026 })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-mono font-semibold text-indigo-700 bg-indigo-50/30"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                  ឆ្នាំគ្រោង (N+2)
                </label>
                <input
                  type="number"
                  value={schoolProfile.yearN2}
                  onChange={(e) => onUpdateProfile({ yearN2: parseInt(e.target.value) || 2027 })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                  ឆ្នាំគ្រោង (N+3)
                </label>
                <input
                  type="number"
                  value={schoolProfile.yearN3}
                  onChange={(e) => onUpdateProfile({ yearN3: parseInt(e.target.value) || 2028 })}
                  className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-500">
              ចំណាំ៖ នៅពេលប្តូរ &ldquo;ឆ្នាំបច្ចុប្បន្ន (N)&rdquo; ប្រព័ន្ធនឹងធ្វើបច្ចុប្បន្នភាពឆ្នាំ N-1, N+1, N+2, N+3 ដោយស្វ័យប្រវត្តិ។
            </div>
          </div>
        </div>

        {/* Card 3: Leadership & Signatures */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-800 font-semibold text-sm">
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>គណៈគ្រប់គ្រង និងហត្ថលេខី</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-600 font-medium mb-1">
                ឈ្មោះនាយកសាលា (School Principal)
              </label>
              <input
                type="text"
                value={schoolProfile.principalName}
                onChange={(e) => onUpdateProfile({ principalName: e.target.value })}
                placeholder="លោក/លោកស្រី..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                ប្រធានគណៈកម្មការគ្រប់គ្រងសាលារៀន (School Committee Chair)
              </label>
              <input
                type="text"
                value={schoolProfile.committeeChair}
                onChange={(e) => onUpdateProfile({ committeeChair: e.target.value })}
                placeholder="លោក/លោកស្រី..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                អ្នករៀបចំផែនការ (Prepared By)
              </label>
              <input
                type="text"
                value={schoolProfile.preparedBy}
                onChange={(e) => onUpdateProfile({ preparedBy: e.target.value })}
                placeholder="លោក/លោកស្រី..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                កាលបរិច្ឆេទអនុម័ត (Date)
              </label>
              <input
                type="text"
                value={schoolProfile.approvalDate}
                onChange={(e) => onUpdateProfile({ approvalDate: e.target.value })}
                placeholder="ថ្ងៃទី ... ខែ ... ឆ្នាំ២០២៥"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Card 4: Official Conclusion */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 text-slate-800 font-semibold text-sm">
              <FileText className="w-4 h-4 text-amber-600" />
              <span>សេចក្ដីសន្និដ្ឋាន (Conclusion)</span>
            </div>
            <button
              onClick={onResetConclusion}
              className="text-[11px] text-slate-500 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
              title="ផ្ទុកអត្ថបទគំរូដើមរបស់ MoEYS"
            >
              <RotateCcw className="w-3 h-3" />
              <span>អត្ថបទគំរូ MoEYS</span>
            </button>
          </div>

          <div className="space-y-2 text-xs">
            <p className="text-slate-500 text-[11px]">
              ខ្លឹមសារសេចក្តីសន្និដ្ឋានដែលត្រូវបង្ហាញនៅចុងបញ្ចប់នៃឯកសារបោះពុម្ព BSP៖
            </p>
            <textarea
              rows={10}
              value={schoolProfile.conclusionNotes}
              onChange={(e) => onUpdateProfile({ conclusionNotes: e.target.value })}
              placeholder="បញ្ចូលខ្លឹមសារសេចក្តីសន្និដ្ឋាន..."
              className="w-full p-3 border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 focus:outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
