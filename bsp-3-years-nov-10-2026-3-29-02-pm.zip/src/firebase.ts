import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDocFromServer,
  setDoc,
  getDoc,
  getDocs,
  collection,
  deleteDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { IndicatorRow, ActivityBudgetRow, SchoolProfile } from './data/bspData';
import { StrategicDocument } from './data/reportData';

const app = initializeApp(firebaseConfig);

/* CRITICAL: The app will break without specifying firestoreDatabaseId */
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test Connection function as instructed in SKILL.md
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline. Checking network configuration.');
      return false;
    }
    // If permission or other error, server is still reachable
    return true;
  }
}

export interface BspPlanRecord {
  id: string;
  schoolCode: string;
  schoolName: string;
  cycleTitle: string; // e.g. "ផែនការយុទ្ធសាស្ត្រ ២០២៦-២០២៩" or "ទិន្នន័យគំរូដើម (Baseline 2024-2025)"
  startYear: number;
  endYear: number;
  status: 'active' | 'archived' | 'draft';
  schoolProfile: SchoolProfile;
  doc: StrategicDocument;
  table1Rows: IndicatorRow[];
  table2Rows: ActivityBudgetRow[];
  createdAt: string;
  updatedAt: string;
}

const COLLECTION_NAME = 'bsp_plans';

/**
 * Save a complete BSP Plan cycle snapshot to Firestore
 */
export async function savePlanToFirestore(plan: BspPlanRecord): Promise<void> {
  const path = `${COLLECTION_NAME}/${plan.id}`;
  try {
    const docRef = doc(db, COLLECTION_NAME, plan.id);
    await setDoc(docRef, {
      ...plan,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Retrieve all saved BSP Plan cycles from Firestore
 */
export async function fetchPlansFromFirestore(): Promise<BspPlanRecord[]> {
  const path = COLLECTION_NAME;
  try {
    const q = query(collection(db, COLLECTION_NAME));
    const snapshot = await getDocs(q);
    const plans: BspPlanRecord[] = [];
    snapshot.forEach((d) => {
      plans.push(d.data() as BspPlanRecord);
    });
    // Sort descending by updatedAt
    return plans.sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

/**
 * Delete a plan from Firestore
 */
export async function deletePlanFromFirestore(planId: string): Promise<void> {
  const path = `${COLLECTION_NAME}/${planId}`;
  try {
    const docRef = doc(db, COLLECTION_NAME, planId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
